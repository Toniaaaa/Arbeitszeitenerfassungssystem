//{{NO_DEPENDENCIES}}
// Von Microsoft Visual C++ generierte Includedatei.
// Verwendet durch Zeiterfassungssystem.rc
//
#define IDI_ICON1                       101
#define IDI_ICON2                       102
#define IDR_JPG1                        104
#define IDR_JPG2                        105
#define IDR_JPG3                        106
#define IDR_JPG4                        107
#define IDR_JPG5                        108
#define IDR_JPG6                        109
#define IDR_JPG7                        110
#define IDR_JPG8                        111
#define IDR_JPG9                        112
#define IDR_JPG10                       113
#define IDR_JPG11                       114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
