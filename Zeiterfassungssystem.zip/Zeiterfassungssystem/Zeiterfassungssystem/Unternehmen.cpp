#include "Unternehmen.h"
#include "Angestellter.h"
#include "Abteilung.h"
#include "Vorgesetzter.h"
#include "Mitarbeiter.h"

using  namespace System;
using namespace System::Collections::Generic;
using namespace System::Runtime::Serialization::Formatters::Binary;
using namespace System::IO;

Unternehmen::Unternehmen()
{
	abteilungen = gcnew List<Abteilung^>;
	Abteilung^ administration;
	Vorgesetzter^ admin = gcnew Vorgesetzter("Admin", "istrator", administration, "1", "1234", 169, 28);
	administration = gcnew Abteilung("1", admin);
	admin->setAbteilung(administration);
	abteilungen->Add(administration);
}

//HIER WIRD DAS UNTERNEHMEN DESERIALISIERT DIE DATEN DES USERS WERDEN DESERIALISIERT UND BEIM PASSWORT �NDERN AUCH
//GE�NDERT BZW DAS NEUE AUCH GELADEN DAS PROBLEM SIND DIE EREIGNISSE DIE BEI KLICK AUF KOMMEN GEHEN UND PAUSE IN 
//DIE LISTE GESPEICHERT WERDEN
Unternehmen^ Unternehmen::ladeUnternehmen(String^ file) {
	Unternehmen^ result;
	if (File::Exists(file)) {
		BinaryFormatter^ binary = gcnew BinaryFormatter();
		Stream^ stream = gcnew FileStream(file, FileMode::Open, FileAccess::Read,  FileShare::Read);
		stream->Position = 0;
		result = (Unternehmen^)binary->Deserialize(stream);
		stream->Close();
	}
	else {
		result = gcnew Unternehmen();
	}
	result->file = file;

	return result;
}

//HIER WIRD SERIALISIERT
void Unternehmen::speichern()
{
	FileStream^ filestream = File::Create(file);
	BinaryFormatter^ binary = gcnew BinaryFormatter();
	binary->Serialize(filestream, this);
	filestream->Close();
}

Int32 Unternehmen::getAnzahlAbteilungen()
{
	return abteilungen->Count;
}

Abteilung ^ Unternehmen::getAbteilung(Int32 index)
{
	return abteilungen[index];
}

void Unternehmen::removeAbteilung(Int32 index)
{
	return abteilungen->RemoveAt(index);
}

void Unternehmen::addAbteilung(Abteilung ^ abteilung)
{
	abteilungen->Add(abteilung);
}

List<Angestellter^>^ Unternehmen::getAlleAngestellte()
{
	List<Angestellter^>^ angestellte = gcnew List<Angestellter^>;
	
	for (int i = 0; i < getAnzahlAbteilungen(); i++) {
		Abteilung^ abteilung = getAbteilung(i);
		angestellte->Add(abteilung->getVorgesetzter());
		for (int j = 0; j < abteilung->getAnzahlMitarbeiter(); j++) {
			angestellte->Add(abteilung->getMitarbeiter(j));
		}
	}

	return angestellte;
}

Angestellter ^ Unternehmen::loginaccept(String ^ personalnummer, String ^ passwort)
{
	List<Angestellter^>^ angestellte = getAlleAngestellte();
	Angestellter^ result = nullptr;

	bool gefunden = false;
	for (int i = 0; i < angestellte->Count && !gefunden; i++) {
		Angestellter^ angestellter = angestellte[i];

		if (angestellter->getPersonalnummer()->Equals(personalnummer)) {
			gefunden = true;

			if (angestellter->getPasswort()->Equals(passwort)) {
				result = angestellter;
			}
		}
	} 
	return result;
}
